package com.cdp

annotation class PERSISTENCIADUAL
